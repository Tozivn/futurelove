package com.thinkdiffai.futurelove.presenter.crud;

import android.content.Context;

public interface CommonCrud {
    void deleteAccount(Context context, long id);


}
