package com.thinkdiffai.futurelove.model.comment.EventsUser;

import java.util.List;

public class EventsUser {
    private List<Sukien> list_sukien;

    public List<Sukien> getList_sukien() {
        return list_sukien;
    }

    public void setList_sukien(List<Sukien> list_sukien) {
        this.list_sukien = list_sukien;
    }
}