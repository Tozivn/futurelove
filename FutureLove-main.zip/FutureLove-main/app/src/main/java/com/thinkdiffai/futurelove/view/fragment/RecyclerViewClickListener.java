package com.thinkdiffai.futurelove.view.fragment;

public interface RecyclerViewClickListener {
    void onItemClick(String data1, int id_video_int);
}
