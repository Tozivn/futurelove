package com.thinkdiffai.futurelove.model;

public class Page {
    private int page;

    public Page(int page) {
        this.page = page;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }
}
