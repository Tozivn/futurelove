package com.thinkdiffai.futurelove.util;

public interface Constant {
    String KEY_IMG_BB =  "ddc51a8c2a1ed5ef16a9faf321c6821a";
}
