package com.thinkdiffai.futurelove.model.comment.EventsUser;

import java.util.List;

public class Sukien {
    private List<SukienX> sukien;

    public List<SukienX> getSukien() {
        return sukien;
    }

    public void setSukien(List<SukienX> sukien) {
        this.sukien = sukien;
    }
}