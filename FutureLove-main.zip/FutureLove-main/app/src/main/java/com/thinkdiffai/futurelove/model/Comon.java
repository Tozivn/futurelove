package com.thinkdiffai.futurelove.model;

public class Comon {
    public static String link_da_swap;
    public static String link_nam_chua_swap;
    public static String link_nam_goc;
    public static String link_nu_chua_swap;
    public static String link_nu_goc;
    public static String real_time;
    public static String tom_Luoc_Text;
}
