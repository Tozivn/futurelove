package com.thinkdiffai.futurelove.util.callback;

import androidx.recyclerview.widget.RecyclerView;

public interface ItemTouchHelperListener {
    void onSwipe(RecyclerView.ViewHolder viewHolder);
}
