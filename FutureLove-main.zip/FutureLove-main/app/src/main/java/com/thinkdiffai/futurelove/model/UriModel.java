package com.thinkdiffai.futurelove.model;

import android.net.Uri;

public class UriModel {
    Uri uri;

    public UriModel() {
    }

    public UriModel(Uri uri) {
        this.uri = uri;
    }

    public Uri getUri() {
        return uri;
    }

    public void setUri(Uri uri) {
        this.uri = uri;
    }
}
