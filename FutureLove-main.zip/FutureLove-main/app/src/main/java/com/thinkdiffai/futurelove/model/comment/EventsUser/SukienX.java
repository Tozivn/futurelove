package com.thinkdiffai.futurelove.model.comment.EventsUser;
public class SukienX {
    private Integer id_template;

    private Integer so_thu_tu_su_kien;

    private String real_time;

    private String link_nam_goc;

    private String link_nu_goc;

    private Integer id_user;

    private String link_da_swap;

    private String ten_su_kien;

    private Integer count_comment;

    private String link_nam_chua_swap;

    private Integer phantram_loading;

    private Integer count_view;

    private String link_nu_chua_swap;

    private Integer id;

    private String ten_nu;

    private Integer id_toan_bo_su_kien;

    private String noi_dung_su_kien;

    private String ten_nam;

    public Integer getId_template() {
        return this.id_template;
    }

    public void setId_template(Integer id_template) {
        this.id_template = id_template;
    }

    public Integer getSo_thu_tu_su_kien() {
        return this.so_thu_tu_su_kien;
    }

    public void setSo_thu_tu_su_kien(Integer so_thu_tu_su_kien) {
        this.so_thu_tu_su_kien = so_thu_tu_su_kien;
    }

    public String getReal_time() {
        return this.real_time;
    }

    public void setReal_time(String real_time) {
        this.real_time = real_time;
    }

    public String getLink_nam_goc() {
        return this.link_nam_goc;
    }

    public void setLink_nam_goc(String link_nam_goc) {
        this.link_nam_goc = link_nam_goc;
    }

    public String getLink_nu_goc() {
        return this.link_nu_goc;
    }

    public void setLink_nu_goc(String link_nu_goc) {
        this.link_nu_goc = link_nu_goc;
    }

    public Integer getId_user() {
        return this.id_user;
    }

    public void setId_user(Integer id_user) {
        this.id_user = id_user;
    }

    public String getLink_da_swap() {
        return this.link_da_swap;
    }

    public void setLink_da_swap(String link_da_swap) {
        this.link_da_swap = link_da_swap;
    }

    public String getTen_su_kien() {
        return this.ten_su_kien;
    }

    public void setTen_su_kien(String ten_su_kien) {
        this.ten_su_kien = ten_su_kien;
    }

    public Integer getCount_comment() {
        return this.count_comment;
    }

    public void setCount_comment(Integer count_comment) {
        this.count_comment = count_comment;
    }

    public String getLink_nam_chua_swap() {
        return this.link_nam_chua_swap;
    }

    public void setLink_nam_chua_swap(String link_nam_chua_swap) {
        this.link_nam_chua_swap = link_nam_chua_swap;
    }

    public Integer getPhantram_loading() {
        return this.phantram_loading;
    }

    public void setPhantram_loading(Integer phantram_loading) {
        this.phantram_loading = phantram_loading;
    }

    public Integer getCount_view() {
        return this.count_view;
    }

    public void setCount_view(Integer count_view) {
        this.count_view = count_view;
    }

    public String getLink_nu_chua_swap() {
        return this.link_nu_chua_swap;
    }

    public void setLink_nu_chua_swap(String link_nu_chua_swap) {
        this.link_nu_chua_swap = link_nu_chua_swap;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTen_nu() {
        return this.ten_nu;
    }

    public void setTen_nu(String ten_nu) {
        this.ten_nu = ten_nu;
    }

    public Integer getId_toan_bo_su_kien() {
        return this.id_toan_bo_su_kien;
    }

    public void setId_toan_bo_su_kien(Integer id_toan_bo_su_kien) {
        this.id_toan_bo_su_kien = id_toan_bo_su_kien;
    }

    public String getNoi_dung_su_kien() {
        return this.noi_dung_su_kien;
    }

    public void setNoi_dung_su_kien(String noi_dung_su_kien) {
        this.noi_dung_su_kien = noi_dung_su_kien;
    }

    public String getTen_nam() {
        return this.ten_nam;
    }

    public void setTen_nam(String ten_nam) {
        this.ten_nam = ten_nam;
    }
}