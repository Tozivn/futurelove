from api_manga import *
from api_get_home import *
from api_account_management import *
app.config['CORS_HEADERS'] = 'Content-Type'
cors = CORS(app)
cors = CORS(app, resource={
        r"/*":{
                    "origins":"*"
                        }
        })

if __name__ =="__main__":
	app.run(host='0.0.0.0', port=7979)
